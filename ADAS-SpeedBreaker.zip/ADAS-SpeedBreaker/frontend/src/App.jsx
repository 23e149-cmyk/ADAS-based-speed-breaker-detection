import React, { useEffect, useRef, useState } from "react";
import Header from "./components/Header.jsx";
import CameraPanel from "./components/CameraPanel.jsx";
import RiskGauge from "./components/RiskGauge.jsx";
import SpeedControl from "./components/SpeedControl.jsx";
import StatusPanel from "./components/StatusPanel.jsx";
import WarningBanner from "./components/WarningBanner.jsx";
import DetectionHistory from "./components/DetectionHistory.jsx";
import TrendChart from "./components/TrendChart.jsx";
import { useCamera } from "./hooks/useCamera.js";
import { useWebSocket } from "./hooks/useWebSocket.js";
import { useAudioWarning } from "./hooks/useAudioWarning.js";
import { API_BASE_URL, WARNING_COOLDOWN_S } from "./config.js";

export default function App() {
  const { videoRef, status: cameraStatus, errorMessage: cameraError, start: startCamera } = useCamera();
  const [speedKmh, setSpeedKmh] = useState(30);
  const [history, setHistory] = useState([]);
  const [showWarning, setShowWarning] = useState(false);
  const warningTimeoutRef = useRef(null);
  const { play: playWarningSound } = useAudioWarning();

  const { connectionStatus, backendStatus, latestResult, lastError, warningEvent } = useWebSocket({
    videoRef,
    cameraActive: cameraStatus === "granted",
    speedKmh,
  });

  // Start requesting the camera as soon as the dashboard mounts.
  useEffect(() => {
    startCamera();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Load existing history once on mount (survives page refresh, per
  // requirement 11 - persistent storage via SQLite).
  useEffect(() => {
    fetch(`${API_BASE_URL}/history`)
      .then((res) => res.json())
      .then((data) => setHistory(data.detections || []))
      .catch(() => {
        /* backend may not be up yet - StatusPanel/connection indicators already surface this */
      });
  }, []);

  // Whenever a new detection_result arrives with an actual detection,
  // prepend it to the in-memory history table (kept in sync with SQLite
  // via the backend's own insert-on-detection behaviour).
  useEffect(() => {
    if (latestResult && latestResult.confidence != null) {
      setHistory((prev) => [
        {
          id: `${latestResult.timestamp}`,
          timestamp: latestResult.timestamp * 1000,
          confidence: latestResult.confidence,
          distance_m: latestResult.distance_m,
          speed_kmh: latestResult.vehicle_speed_kmh,
          ttc_s: latestResult.ttc_s,
          risk_level: latestResult.risk_level,
        },
        ...prev,
      ].slice(0, 50));
    }
  }, [latestResult]);

  // Trigger the visual banner + audio beep whenever the backend arms a new
  // warning event. The COOLDOWN itself is enforced server-side
  // (services/warning_service.py) - here we just react to it.
  useEffect(() => {
    if (warningEvent === 0) return;
    setShowWarning(true);
    playWarningSound();
    clearTimeout(warningTimeoutRef.current);
    warningTimeoutRef.current = setTimeout(() => setShowWarning(false), 4000);
    return () => clearTimeout(warningTimeoutRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [warningEvent]);

  return (
    <div className="min-h-screen flex flex-col">
      <WarningBanner visible={showWarning} />
      <Header connectionStatus={connectionStatus} backendStatus={backendStatus} />

      <main className="flex-1 p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Main camera + history column */}
        <section className="lg:col-span-2 flex flex-col gap-5">
          <CameraPanel
            videoRef={videoRef}
            cameraStatus={cameraStatus}
            cameraError={cameraError}
            onRetry={startCamera}
            latestResult={latestResult}
          />

          {lastError && (
            <div className="px-4 py-2 rounded-lg bg-danger/10 border border-danger/40 text-danger text-sm font-mono">
              {lastError}
            </div>
          )}
          {backendStatus && !backendStatus.yolo_loaded && backendStatus.yolo_error && (
            <div className="px-4 py-2 rounded-lg bg-caution/10 border border-caution/40 text-caution text-sm font-mono">
              {backendStatus.yolo_error}
            </div>
          )}

          <DetectionHistory rows={history} />
          <TrendChart rows={history} />
        </section>

        {/* Right sidebar: gauge, speed control, status */}
        <aside className="flex flex-col gap-5">
          <div className="bg-panel border border-panelborder rounded-lg p-4 flex flex-col items-center">
            <RiskGauge
              riskLevel={latestResult?.risk_level || "SAFE"}
              ttcS={latestResult?.ttc_s}
              distanceM={latestResult?.distance_m}
            />
            <p className="text-[10px] text-steel-500 font-mono mt-2 text-center">
              Warnings are cooled down to at most one every {WARNING_COOLDOWN_S}s
            </p>
          </div>

          <SpeedControl speedKmh={speedKmh} onChange={setSpeedKmh} />

          <StatusPanel
            cameraStatus={cameraStatus}
            connectionStatus={connectionStatus}
            backendStatus={backendStatus}
            latestResult={latestResult}
          />
        </aside>
      </main>

      <footer className="px-6 py-3 text-center text-[11px] text-steel-500 font-mono border-t border-panelborder">
        Distances are ESTIMATED via monocular approximation - not survey-grade accurate. Manual speed input, academic prototype.
      </footer>
    </div>
  );
}
