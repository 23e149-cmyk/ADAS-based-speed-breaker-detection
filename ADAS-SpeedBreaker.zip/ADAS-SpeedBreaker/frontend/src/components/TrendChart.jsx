import React from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

export default function TrendChart({ rows }) {
  // rows come newest-first from the backend; charts read better oldest-first.
  const data = [...rows]
    .slice(0, 20)
    .reverse()
    .map((row, i) => ({
      idx: i,
      distance: row.distance_m,
      confidence: row.confidence * 100,
    }));

  return (
    <div className="bg-panel border border-panelborder rounded-lg p-4">
      <h3 className="font-hud text-sm tracking-widest text-steel-300 mb-3">
        DISTANCE &amp; CONFIDENCE TREND
      </h3>
      {data.length < 2 ? (
        <p className="text-steel-500 font-mono text-xs py-8 text-center">
          Not enough detection history yet to plot a trend.
        </p>
      ) : (
        <ResponsiveContainer width="100%" height={180}>
          <LineChart data={data} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid stroke="#232935" strokeDasharray="3 3" />
            <XAxis dataKey="idx" tick={false} stroke="#232935" />
            <YAxis yAxisId="left" stroke="#8A93A3" tick={{ fontSize: 10 }} width={30} />
            <YAxis yAxisId="right" orientation="right" stroke="#8A93A3" tick={{ fontSize: 10 }} width={30} />
            <Tooltip
              contentStyle={{ background: "#12161D", border: "1px solid #232935", fontSize: 12 }}
              labelFormatter={() => ""}
            />
            <Line yAxisId="left" type="monotone" dataKey="distance" stroke="#3DDAFF" strokeWidth={2} dot={false} name="Distance (m)" />
            <Line yAxisId="right" type="monotone" dataKey="confidence" stroke="#FFB020" strokeWidth={2} dot={false} name="Confidence (%)" />
          </LineChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
