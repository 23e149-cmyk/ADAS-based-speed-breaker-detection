import React, { useMemo } from "react";
import { RISK_COLORS } from "../config.js";

const CX = 100;
const CY = 100;
const R = 78;

// Angle bands in degrees, sweeping 180 (left) -> 360 (right) across the
// TOP semicircle (screen/SVG angle convention: 0deg = 3 o'clock, clockwise).
const BANDS = {
  SAFE: [180, 240],
  CAUTION: [240, 300],
  HIGH_RISK: [300, 360],
};

function polarToCartesian(cx, cy, r, angleDeg) {
  const rad = (angleDeg * Math.PI) / 180;
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
}

function describeArc(cx, cy, r, startAngle, endAngle) {
  const start = polarToCartesian(cx, cy, r, startAngle);
  const end = polarToCartesian(cx, cy, r, endAngle);
  const largeArcFlag = endAngle - startAngle <= 180 ? 0 : 1;
  return `M ${start.x} ${start.y} A ${r} ${r} 0 ${largeArcFlag} 1 ${end.x} ${end.y}`;
}

/**
 * Maps the backend's discrete risk_level plus (optional) TTC into a needle
 * angle. The discrete risk_level (computed by services/risk_engine.py) is
 * authoritative for WHICH band the needle sits in; TTC only fine-tunes the
 * needle's position within that band for a smoother, more informative
 * sweep. This is a display convenience, not a safety computation - the
 * numeric TTC/distance/risk values shown alongside the gauge are the
 * ground truth.
 */
function needleAngle(riskLevel, ttcS) {
  const [start, end] = BANDS[riskLevel] || BANDS.SAFE;
  if (ttcS == null) {
    return riskLevel === "HIGH_RISK" ? end - 4 : (start + end) / 2;
  }
  const t = Math.max(0, Math.min(1, 1 - ttcS / 10));
  return start + t * (end - start);
}

export default function RiskGauge({ riskLevel = "SAFE", ttcS, distanceM }) {
  const angle = useMemo(() => needleAngle(riskLevel, ttcS), [riskLevel, ttcS]);
  const needleTip = polarToCartesian(CX, CY, R - 12, angle);
  const color = RISK_COLORS[riskLevel] || RISK_COLORS.SAFE;

  return (
    <div className="flex flex-col items-center">
      <svg viewBox="0 0 200 120" className="w-full max-w-[280px]">
        {/* Background track */}
        <path d={describeArc(CX, CY, R, 180, 360)} stroke="#232935" strokeWidth="14" fill="none" strokeLinecap="round" />
        {/* Colored bands */}
        <path d={describeArc(CX, CY, R, BANDS.SAFE[0], BANDS.SAFE[1])} stroke={RISK_COLORS.SAFE} strokeOpacity="0.55" strokeWidth="14" fill="none" />
        <path d={describeArc(CX, CY, R, BANDS.CAUTION[0], BANDS.CAUTION[1])} stroke={RISK_COLORS.CAUTION} strokeOpacity="0.55" strokeWidth="14" fill="none" />
        <path d={describeArc(CX, CY, R, BANDS.HIGH_RISK[0], BANDS.HIGH_RISK[1])} stroke={RISK_COLORS.HIGH_RISK} strokeOpacity="0.55" strokeWidth="14" fill="none" />

        {/* Needle */}
        <line x1={CX} y1={CY} x2={needleTip.x} y2={needleTip.y} stroke={color} strokeWidth="3" strokeLinecap="round" />
        <circle cx={CX} cy={CY} r="6" fill={color} />

        {/* Readout */}
        <text x={CX} y={CY - 24} textAnchor="middle" className="font-mono" fontSize="22" fontWeight="700" fill={color}>
          {ttcS != null ? `${ttcS.toFixed(1)}s` : "--"}
        </text>
        <text x={CX} y={CY - 8} textAnchor="middle" className="font-hud" fontSize="11" letterSpacing="1.5" fill="#8A93A3">
          TIME TO COLLISION
        </text>
      </svg>
      <div
        className="mt-1 px-4 py-1 rounded-full font-hud font-bold tracking-widest text-sm"
        style={{ color, backgroundColor: `${color}1A`, border: `1px solid ${color}66` }}
      >
        {riskLevel.replace("_", " ")}
      </div>
      {distanceM != null && (
        <p className="text-xs text-steel-500 font-mono mt-1">est. distance {distanceM.toFixed(1)} m</p>
      )}
    </div>
  );
}
