import React from "react";

function StatusPill({ label, ok, unknown }) {
  const color = unknown ? "bg-steel-500" : ok ? "bg-safe" : "bg-danger";
  return (
    <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-panel border border-panelborder">
      <span className={`h-2 w-2 rounded-full ${color} ${!unknown && !ok ? "animate-pulse_danger" : ""}`} />
      <span className="text-xs font-mono text-steel-300 tracking-wide">{label}</span>
    </div>
  );
}

export default function Header({ connectionStatus, backendStatus }) {
  const backendOk = connectionStatus === "connected";
  const yoloOk = backendStatus?.yolo_loaded === true;

  return (
    <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-4 border-b border-panelborder">
      <div>
        <h1 className="font-hud text-2xl sm:text-3xl font-bold tracking-wide text-steel-100">
          ADAS <span className="text-info">SPEED BREAKER</span> DETECTION SYSTEM
        </h1>
        <p className="text-xs text-steel-500 font-mono mt-0.5">
          Academic prototype &mdash; monocular vision, single-class hazard detection
        </p>
      </div>
      <div className="flex flex-wrap gap-2">
        <StatusPill label={`BACKEND: ${backendOk ? "ONLINE" : connectionStatus.toUpperCase()}`} ok={backendOk} />
        <StatusPill
          label={`YOLO: ${yoloOk ? "LOADED" : "NOT LOADED"}`}
          ok={yoloOk}
          unknown={!backendOk}
        />
        {backendStatus?.device && (
          <StatusPill label={`DEVICE: ${backendStatus.device.toUpperCase()}`} ok={true} />
        )}
      </div>
    </header>
  );
}
