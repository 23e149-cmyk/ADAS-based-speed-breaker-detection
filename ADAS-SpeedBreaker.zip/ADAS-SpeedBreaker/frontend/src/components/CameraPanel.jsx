import React, { useEffect, useRef } from "react";
import { RISK_COLORS } from "../config.js";

function OverlayCanvas({ videoRef, detections, riskLevel }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video) return;

    const draw = () => {
      const displayWidth = video.clientWidth;
      const displayHeight = video.clientHeight;
      if (canvas.width !== displayWidth) canvas.width = displayWidth;
      if (canvas.height !== displayHeight) canvas.height = displayHeight;

      const ctx = canvas.getContext("2d");
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (!detections || detections.length === 0) return;

      const color = RISK_COLORS[riskLevel] || RISK_COLORS.SAFE;

      detections.forEach((det) => {
        // Detections carry the pixel dims of the (resized) inference frame
        // so we can scale bounding boxes onto whatever size the <video>
        // element is actually rendered at.
        const scaleX = displayWidth / det.frame_width;
        const scaleY = displayHeight / det.frame_height;
        const [x1, y1, x2, y2] = det.bbox;

        const rx = x1 * scaleX;
        const ry = y1 * scaleY;
        const rw = (x2 - x1) * scaleX;
        const rh = (y2 - y1) * scaleY;

        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        ctx.strokeRect(rx, ry, rw, rh);

        const label = `SPEED BREAKER ${(det.confidence * 100).toFixed(0)}%`;
        ctx.font = "600 13px 'JetBrains Mono', monospace";
        const textWidth = ctx.measureText(label).width;

        ctx.fillStyle = color;
        ctx.fillRect(rx - 1, Math.max(0, ry - 20), textWidth + 10, 20);
        ctx.fillStyle = "#0A0D12";
        ctx.fillText(label, rx + 4, Math.max(14, ry - 5));
      });
    };

    draw();
    const observer = new ResizeObserver(draw);
    observer.observe(video);
    return () => observer.disconnect();
  }, [videoRef, detections, riskLevel]);

  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />;
}

function Corner({ position }) {
  const base = "hud-corner";
  const styles = {
    tl: `${base} top-3 left-3 border-t-2 border-l-2`,
    tr: `${base} top-3 right-3 border-t-2 border-r-2`,
    bl: `${base} bottom-3 left-3 border-b-2 border-l-2`,
    br: `${base} bottom-3 right-3 border-b-2 border-r-2`,
  };
  return <div className={styles[position]} />;
}

export default function CameraPanel({ videoRef, cameraStatus, cameraError, onRetry, latestResult }) {
  const showVideo = cameraStatus === "granted";

  return (
    <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden border border-panelborder">
      <video
        ref={videoRef}
        className={`w-full h-full object-cover ${showVideo ? "" : "hidden"}`}
        muted
        playsInline
      />

      {showVideo && (
        <>
          <OverlayCanvas
            videoRef={videoRef}
            detections={latestResult?.detections}
            riskLevel={latestResult?.risk_level}
          />
          <Corner position="tl" />
          <Corner position="tr" />
          <Corner position="bl" />
          <Corner position="br" />
          <div className="absolute inset-x-3 top-3 h-px bg-info/30 overflow-hidden">
            <div className="w-full h-px bg-info animate-scan" />
          </div>
          <div className="absolute top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded bg-black/50 backdrop-blur-sm font-mono text-[11px] text-info tracking-widest">
            LIVE FEED
          </div>
        </>
      )}

      {!showVideo && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 px-6 text-center">
          {cameraStatus === "idle" && (
            <>
              <p className="text-steel-300 font-body text-sm max-w-sm">
                This dashboard needs access to your webcam to run live speed-breaker detection.
              </p>
              <button
                onClick={onRetry}
                className="px-5 py-2 rounded-md bg-info/10 border border-info text-info font-hud font-semibold tracking-wide hover:bg-info/20 transition-colors"
              >
                ENABLE CAMERA
              </button>
            </>
          )}
          {cameraStatus === "pending" && (
            <p className="text-steel-300 font-mono text-sm animate-pulse">Requesting camera permission...</p>
          )}
          {(cameraStatus === "denied" || cameraStatus === "unavailable" || cameraStatus === "disconnected") && (
            <>
              <p className="text-danger font-hud font-semibold tracking-wide">
                {cameraStatus === "denied" && "CAMERA PERMISSION DENIED"}
                {cameraStatus === "unavailable" && "CAMERA UNAVAILABLE"}
                {cameraStatus === "disconnected" && "CAMERA DISCONNECTED"}
              </p>
              <p className="text-steel-300 text-sm max-w-sm">{cameraError}</p>
              <button
                onClick={onRetry}
                className="px-5 py-2 rounded-md bg-panel border border-panelborder text-steel-100 font-hud font-semibold tracking-wide hover:border-info transition-colors"
              >
                RETRY
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}
