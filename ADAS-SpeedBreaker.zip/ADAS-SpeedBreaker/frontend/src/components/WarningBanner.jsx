import React from "react";

export default function WarningBanner({ visible }) {
  if (!visible) return null;

  return (
    <div
      role="alert"
      className="fixed inset-x-0 top-0 z-50 flex justify-center pointer-events-none"
    >
      <div className="mt-4 mx-4 px-6 py-3 rounded-lg bg-danger/95 shadow-glow_danger border border-red-300/40 animate-pulse_danger pointer-events-auto">
        <p className="font-hud font-extrabold tracking-widest text-black text-center text-lg sm:text-xl">
          SPEED BREAKER AHEAD &mdash; SLOW DOWN
        </p>
      </div>
    </div>
  );
}
