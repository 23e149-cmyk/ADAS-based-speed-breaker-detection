import React from "react";

function StatCard({ label, value, accent }) {
  return (
    <div className="bg-panel border border-panelborder rounded-lg px-3 py-2.5">
      <p className="text-[10px] font-hud tracking-widest text-steel-500 mb-1">{label}</p>
      <p className={`font-mono text-lg font-semibold ${accent || "text-steel-100"}`}>{value}</p>
    </div>
  );
}

const CAMERA_LABELS = {
  idle: ["NOT STARTED", "text-steel-500"],
  pending: ["REQUESTING...", "text-caution"],
  granted: ["CONNECTED", "text-safe"],
  denied: ["PERMISSION DENIED", "text-danger"],
  unavailable: ["UNAVAILABLE", "text-danger"],
  disconnected: ["DISCONNECTED", "text-danger"],
};

export default function StatusPanel({ cameraStatus, connectionStatus, backendStatus, latestResult }) {
  const [camLabel, camColor] = CAMERA_LABELS[cameraStatus] || CAMERA_LABELS.idle;

  const confidence = latestResult?.confidence != null ? `${(latestResult.confidence * 100).toFixed(0)}%` : "--";
  const fps = latestResult?.fps != null ? latestResult.fps.toFixed(1) : "--";
  const inferenceTime = latestResult?.inference_time_ms != null ? `${latestResult.inference_time_ms.toFixed(0)} ms` : "--";

  return (
    <div className="grid grid-cols-2 gap-3">
      <StatCard label="CAMERA STATUS" value={camLabel} accent={camColor} />
      <StatCard
        label="YOLO STATUS"
        value={backendStatus?.yolo_loaded ? "LOADED" : "NOT LOADED"}
        accent={backendStatus?.yolo_loaded ? "text-safe" : "text-danger"}
      />
      <StatCard
        label="BACKEND LINK"
        value={connectionStatus.toUpperCase()}
        accent={connectionStatus === "connected" ? "text-safe" : "text-danger"}
      />
      <StatCard label="FPS" value={fps} accent="text-info" />
      <StatCard label="DETECTION CONFIDENCE" value={confidence} accent="text-info" />
      <StatCard label="YOLO INFERENCE TIME" value={inferenceTime} accent="text-info" />
    </div>
  );
}
