import React from "react";

export default function SpeedControl({ speedKmh, onChange }) {
  return (
    <div className="bg-panel border border-panelborder rounded-lg p-4">
      <div className="flex items-center justify-between mb-2">
        <h3 className="font-hud text-sm tracking-widest text-steel-300">VEHICLE SPEED</h3>
        <span className="text-[10px] font-mono uppercase text-caution/80 border border-caution/40 px-2 py-0.5 rounded">
          prototype &middot; manual input
        </span>
      </div>

      <div className="flex items-end gap-3">
        <span className="font-mono text-4xl font-bold text-steel-100 tabular-nums">
          {speedKmh.toFixed(0)}
        </span>
        <span className="text-steel-500 font-mono text-sm mb-1">km/h</span>
      </div>

      <input
        type="range"
        min={0}
        max={140}
        step={1}
        value={speedKmh}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full mt-3 accent-info"
        aria-label="Vehicle speed slider"
      />

      <div className="flex items-center gap-2 mt-2">
        <input
          type="number"
          min={0}
          max={300}
          value={speedKmh}
          onChange={(e) => onChange(Number(e.target.value))}
          className="w-24 bg-void border border-panelborder rounded px-2 py-1 font-mono text-sm text-steel-100 focus:outline-none focus:border-info"
          aria-label="Vehicle speed exact value"
        />
        <p className="text-[11px] text-steel-500">
          No vehicle speed sensor is connected in this prototype - set speed manually to test TTC/risk behaviour.
        </p>
      </div>
    </div>
  );
}
