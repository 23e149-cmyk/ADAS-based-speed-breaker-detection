import React from "react";
import { RISK_COLORS } from "../config.js";

function RiskBadge({ level }) {
  const color = RISK_COLORS[level] || RISK_COLORS.SAFE;
  return (
    <span
      className="px-2 py-0.5 rounded text-[11px] font-hud font-bold tracking-wide"
      style={{ color, backgroundColor: `${color}1A`, border: `1px solid ${color}55` }}
    >
      {level.replace("_", " ")}
    </span>
  );
}

export default function DetectionHistory({ rows }) {
  return (
    <div className="bg-panel border border-panelborder rounded-lg overflow-hidden">
      <div className="px-4 py-3 border-b border-panelborder">
        <h3 className="font-hud text-sm tracking-widest text-steel-300">DETECTION HISTORY</h3>
      </div>
      <div className="overflow-x-auto max-h-72 overflow-y-auto">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-panel">
            <tr className="text-left text-[11px] text-steel-500 font-hud tracking-widest border-b border-panelborder">
              <th className="px-4 py-2">TIMESTAMP</th>
              <th className="px-4 py-2">CONFIDENCE</th>
              <th className="px-4 py-2">DISTANCE (m)</th>
              <th className="px-4 py-2">SPEED (km/h)</th>
              <th className="px-4 py-2">TTC (s)</th>
              <th className="px-4 py-2">RISK</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-6 text-center text-steel-500 font-mono text-xs">
                  No detections yet. History will populate as speed breakers are detected.
                </td>
              </tr>
            )}
            {rows.map((row, i) => (
              <tr key={row.id ?? i} className="border-b border-panelborder/60 font-mono text-xs text-steel-300">
                <td className="px-4 py-2 whitespace-nowrap">
                  {new Date(row.timestamp).toLocaleTimeString()}
                </td>
                <td className="px-4 py-2">{(row.confidence * 100).toFixed(0)}%</td>
                <td className="px-4 py-2">{row.distance_m?.toFixed?.(1) ?? row.distance_m}</td>
                <td className="px-4 py-2">{row.speed_kmh?.toFixed?.(0) ?? row.speed_kmh}</td>
                <td className="px-4 py-2">{row.ttc_s != null ? row.ttc_s.toFixed(1) : "--"}</td>
                <td className="px-4 py-2">
                  <RiskBadge level={row.risk_level} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
